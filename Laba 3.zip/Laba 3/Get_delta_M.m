function [M] = Get_delta_M(n, alpha, H, H_grad, x_a, sigma_a, B, B_grad)

    M = zeros(alpha, alpha);

    for i = 1 : alpha
        for j = 1 : alpha

            M(i,j) = trace(H_grad{i} * Get_C(n, alpha, 0) * (x_a * x_a' + sigma_a) * Get_C(n, alpha,0)' * H_grad{j}' / B)...
                    + trace(H_grad{i} * Get_C(n, alpha, 0) * (x_a * x_a' + sigma_a) * Get_C(n, alpha,j)' * H' / B) ...
                    + trace(H * Get_C(n, alpha, i) * (x_a * x_a' + sigma_a) * Get_C(n, alpha,0)' * H_grad{j}' / B) ...
                    + trace(H * Get_C(n, alpha, i) * (x_a * x_a' + sigma_a) * Get_C(n, alpha,j)' * H' / B) ...
                    + 0.5 * trace(B_grad{i} / B * B_grad{j} / B);
        end
    end

end