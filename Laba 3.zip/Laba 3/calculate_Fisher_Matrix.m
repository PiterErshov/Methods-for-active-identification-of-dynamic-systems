function [M_grad] = calculate_Fisher_Matrix(theta, N)
    [F, Psi, Gamma, H, Q, R, x0, P0, u] = init_data(theta);
    [F_grad, Psi_grad, Gamma_grad, H_grad, Q_grad, R_grad, x0_grad] = init_grad();

    n_1 = size(x0,1);
    n_2 = size(x0,2);
    alpha = length(theta);
    r = length(u);
    % выделение памяти
    M_grad = cell(r, N); %zeros(alpha, alpha);
    for i = 1: r
        for j = 1: N
            M_grad{i, j} = zeros(alpha, alpha);
        end
    end
    
    dM = cell(r, N); %zeros(alpha, alpha);
    for i = 1: r
        for j = 1: N
            dM{i, j} = zeros(alpha, alpha);
        end
    end
    dM_buf = zeros(alpha, alpha);
    
    x_a = zeros(n_1 * (alpha + 1), r);
    F_a = zeros(n_1 * (alpha + 1), n_1 * (alpha + 1));
    
    % сформировать матрицу пси(а) по формуле 24

    Psi_a = zeros(n_1 * (alpha + 1), n_2);

    Psi_a(1:n_1, :) = Psi;

    for i = 1 : alpha
       Psi_a(n_1*i+1 : n_1*(i+1), :) = Psi_grad{i}; 
    end
    
    Psi_a_grad = cell(r, 1); %zeros(n_1 * (alpha + 1), r);
    for i = 1: r
        Psi_a_grad{i} = zeros(n_1 * (alpha + 1), r);
    end
    
    x_a_all = cell(N, N);
    x_a_grad = cell(r, 1);%zeros(n_1 * (alpha + 1), r);
    for i = 1: r
        x_a_grad{i} = zeros(n_1 * (alpha + 1), r);
    end
    for i = 1: N
        for j = 1: N
            x_a_all{i, j} = x_a_grad;
        end
    end
    % задание начальных условий  2 шаг
    P_k = P0;

    for k = 0 : N - 1
        if (k == 0) % то 4 шаг, затем 8
            x_a(1 : n_1*1, :) = F*x0 +  Psi * u;                   % 21 u0

            for i = 1 : alpha
                x_a(n_1*i + 1 : n_1*(i+1), :) = F_grad{i} * x0 + F * x0_grad{i} + Psi_grad{i} * u; % u0
            end    
        end

        % 5-7 шаги
        if (k ~= 0)
            % 5 шаг
            K_ = F * K;
            
            % 6 шаг 

            F_a(1:n_1, 1:n_1) = F;
            for i = 1 : alpha
               F_a(n_1*i+1 : n_1*(i+1), 1:n_1) = F_grad{i} - K_ * H_grad{i};

               F_a(n_1*i+1 : n_1*(i+1), n_1*i+1 : n_1*(i+1)) = F - K_ * H;
            end
           
            % 7 шаг
            x_a = F_a * x_a + Psi_a * u(k);
        end
        % 8 шаг

        P_k1_k = F * P_k * F' + Gamma * Q * Gamma'; % 10 формула        
        B = H * P_k1_k * H' + R;                 % 12
        K = P_k1_k * H' / B;                     % 13
        P_k1 = (eye(n_1) - K * H) * P_k1_k;     % 15

        
        for b = 0 : N - 1            
            if (k == 0)                                   
                if (b == k) 
                    for i = 1 : r
                        u_g = zeros(r, 1);
                        u_g(i) = 1;
                        Psi_a_grad{i} = Psi_a * u_g;
                    end                    
                end
                if (b ~= k)    
                    for i = 1 : r
                        Psi_a_grad{i} = zeros(n_1 * (alpha + 1), r);
                    end                    
                end
                
                for i = 1 : r
                    x_a_grad{i} = Psi_a_grad{i};
                end   
            end
            
            if(k ~= 0)
                if (b == k) 
                    for i = 1 : r
                        u_g = zeros(r, 1);
                        u_g(i) = 1;
                        Psi_a_grad{i} = Psi_a * u_g;
                    end                    
                end
                if (b ~= k)    
                    for i = 1 : r
                        Psi_a_grad{i} = zeros(n_1 * (alpha + 1), r);
                    end                    
                end
                x_a_grad = x_a_all{k, b + 1};
                for i = 1 : r
                        x_a_grad{i} = F_a * x_a_grad{i} + Psi_a_grad{i};
                end                
            end

            for t = 1: r
                % шаг 9
                dM_buf = dM{t, b + 1};
                for i = 1 : alpha
                    for j = 1 : alpha

                        dM_buf(i,j) = trace(H_grad{i} * Get_C(n_1, alpha, 0) * (x_a_grad{t} * x_a' + x_a * x_a_grad{t}') * Get_C(n_1, alpha,0)' * H_grad{j}' / B)...
                            + trace(H_grad{i} * Get_C(n_1, alpha, 0) * (x_a_grad{t} * x_a' + x_a * x_a_grad{t}') * Get_C(n_1, alpha,j)' * H' / B) ...
                            + trace(H * Get_C(n_1, alpha, i) * (x_a_grad{t} * x_a' + x_a * x_a_grad{t}') * Get_C(n_1, alpha,0)' * H_grad{j}' / B) ...
                            + trace(H * Get_C(n_1, alpha, i) * (x_a_grad{t} * x_a' + x_a * x_a_grad{t}') * Get_C(n_1, alpha,j)' * H' / B);
                    end
                end
                dM{t, b + 1} = dM_buf;
                M_grad{t, b + 1} = M_grad{t, b + 1} + dM{t, b + 1};
            end
            x_a_all{k + 1, b + 1} = x_a_grad;
        end
        P_k = P_k1;
    end
end