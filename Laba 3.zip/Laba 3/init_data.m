function [F, Psi, Gamma, H, Q, R, x0, P0, u] = init_data(theta)
 
    F =  [-0.8, 1;
          theta(1), 0];
    Psi =  [1; 1];
    Gamma = [1; 1];
    H = [1, 1];

    Q = theta(2);
    R = 0.1;
    x0 = [0; 0];
    P0 = [0.1, 0;
          0, 0.1];
    u = [3];
end
