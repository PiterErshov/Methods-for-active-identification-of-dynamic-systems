N = 2;
% истинная тета
theta_ist = [-1.5; 0.5];

M = calculate_Fisher_Matrix(theta_ist, N);
disp(M{1});
disp(M{2});