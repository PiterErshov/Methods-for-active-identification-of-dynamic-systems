function [C] = Get_C(n, alpha,  i)

    n2 = (alpha+1) * n;
    C = zeros(n, n2);
    
    C(:, n*i + 1 : n*(i+1)) = eye(n);
       
end
