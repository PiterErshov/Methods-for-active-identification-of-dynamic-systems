function [M] = calculate_Fisher_Matrix(theta, N)
    [F, Psi, Gamma, H, Q, R, x0, P0, u] = init_data(theta);
    [F_grad, Psi_grad, Gamma_grad, H_grad, Q_grad, R_grad, x0_grad, P0_grad] = init_grad();

    n_1 = size(x0,1);
    n_2 = size(x0,2);
    alpha = length(theta);

    % выделение памяти
    M = zeros(alpha, alpha);
    dM = zeros(alpha, alpha);
    x_a = zeros(n_1 * (alpha + 1), n_2);
    sigma_a = zeros(alpha, alpha);
    P_k1_k_grad = cell(alpha,1);
    P_k_k_grad = cell(alpha, 1);
    B_grad = cell(alpha,1);
    K_grad = cell(alpha,1);
    K_grad_ = cell(alpha,1);
    P_k1_k1_grad = cell(alpha,1);
    F_a = zeros(n_1 * (alpha + 1), n_1 * (alpha + 1));
    K_a = zeros(n_1 * (alpha + 1), 1);

    % сформировать матрицу пси(а) по формуле 24

    Psi_a = zeros(n_1 * (alpha + 1), n_2);

    Psi_a(1:n_1, :) = Psi;

    for i = 1 : alpha
       Psi_a(n_1*i+1 : n_1*(i+1), :) = Psi_grad{i}; 
    end

    % задание начальных условий  2 шаг
    P_k = P0;

    for i = 1 : alpha
        P_k_k_grad(i) = {P0_grad{i}};
    end


    for k = 0 : N - 1
        u = u;
        if (k == 0) % то 4 шаг, затем 8

            x_a(1 : n_1*1, :) = F*x0 +  Psi * u;                   % 21 u0

            for i = 1 : alpha
                x_a(n_1*i + 1 : n_1*(i+1), :) = F_grad{i} * x0 + F * x0_grad{i} + Psi_grad{i} * u; % u0
            end    

            sigma_a = zeros(n_1 * (alpha + 1), n_1 * (alpha + 1)); % 22
        end

        % 5-7 шаги
        if (k ~= 0)
            % 5 шаг
            K_ = F * K;
            for i = 1 : alpha
               K_grad_(i) = {F_grad{i} * K + F * K_grad{i}};
            end

            % 6 шаг 

            F_a(1:n_1, 1:n_1) = F;
            for i = 1 : alpha
               F_a(n_1*i+1 : n_1*(i+1), 1:n_1) = F_grad{i} - K_ * H_grad{i};

               F_a(n_1*i+1 : n_1*(i+1), n_1*i+1 : n_1*(i+1)) = F - K_ * H;
            end

            K_a(1:n_1) = K_;
            for i = 1 : alpha
                K_a(n_1*i+1 : n_1*(i+1)) = K_grad_{i};
            end

            % 7 шаг

            x_a = F_a * x_a + Psi_a * u;

            sigma_a = F_a * sigma_a * F_a' + K_a * B * K_a';


        end
        % 8 шаг

        P_k1_k = F * P_k * F' + Gamma * Q * Gamma'; % 10 формула

        for i = 1 : alpha
            P_k1_k_grad(i) = {F_grad{i} * P_k * F' + F * P_k_k_grad{i} * F' ...
                + F * P_k * F_grad{i}' + Gamma_grad{i} * Q * Gamma' + Gamma * Q_grad{i} * Gamma'  ...
                + Gamma * Q * Gamma_grad{i}'};
        end


        B = H * P_k1_k * H' + R;                 % 12

        for i = 1 : alpha
            B_grad(i) = {H_grad{i} * P_k1_k * H' + H * P_k1_k_grad{i} * H' ...
                + H * P_k1_k * H_grad{i}'  + R_grad{i}};

        end

        K = P_k1_k * H' / B;                     % 13

        for i = 1 : alpha
            K_grad(i) = {(P_k1_k_grad{i} * H' + P_k1_k * H_grad{i}' ...
                - P_k1_k * H' / B * B_grad{i}) / B};
        end

        P_k1 = (eye(n_1) - K * H) * P_k1_k;     % 15

        for i = 1 : alpha
            P_k1_k1_grad(i) = {(eye(n_1) - K * H) * P_k1_k_grad{i} ...
                - (K_grad{i} * H + K * H_grad{i}) * P_k1_k};
        end
        
        % шаг 9
        for i = 1 : alpha
            for j = 1 : alpha

                dM(i,j) = trace(H_grad{i} * Get_C(n_1, alpha, 0) * (x_a * x_a' + sigma_a) * Get_C(n_1, alpha,0)' * H_grad{j}' / B)...
                    + trace(H_grad{i} * Get_C(n_1, alpha, 0) * (x_a * x_a' + sigma_a) * Get_C(n_1, alpha,j)' * H' / B) ...
                    + trace(H * Get_C(n_1, alpha, i) * (x_a * x_a' + sigma_a) * Get_C(n_1, alpha,0)' * H_grad{j}' / B) ...
                    + trace(H * Get_C(n_1, alpha, i) * (x_a * x_a' + sigma_a) * Get_C(n_1, alpha,j)' * H' / B) ...
                    + 0.5 * trace(B_grad{i} / B * B_grad{j} / B);
            end
        end

        M = M + dM;
        P_k = P_k1;
        P_k_k_grad = P_k1_k1_grad;
    end
end