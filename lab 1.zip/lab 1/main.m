N = 30;
t_n = 5;

theta_ist = [-1.5; 0.5];

theta_1 = zeros(2,t_n);
theta_2 = zeros(2,t_n);
rng(0, 'twister');

for i = 1 : t_n
    [ ~, ~, ~, ~, ~, ~, ~, ~, ~, X, Y] = initial_data(theta_ist, N);

    opt = optimoptions('fmincon', 'Algorithm', 'interior-point');
    fun = @(x) algorithm_1(x, Y);
    theta_1(:,i) = fmincon(fun, [-1; 0.1], [], [], [], [], [-2; 0.01], [-0.05; 0.8], [], opt);
    
    opt = optimoptions('fmincon', 'Algorithm', 'interior-point', 'SpecifyObjectiveGradient',true, 'GradObj','on');
    fun_grad = @(x) algorithm_2(x, Y);
    theta_2(:,i) = fmincon(fun_grad, [-1; 0.1], [], [], [], [], [-2; 0.01], [-0.05; 0.8], [], opt);
end

disp(theta_1)
disp(theta_2)
m_1 = mean(theta_1, 2)
m_2 = mean(theta_2, 2)
norm(theta_ist - m_1) / norm(theta_ist);
norm(theta_ist - m_2) / norm(theta_ist)
