function [F_grad, Psi_grad, Gamma_grad, H_grad, Q_grad, R_grad, x0_grad, P0_grad] = initial_gradient(theta)

    F_grad = cell(2,1);
    F_grad{1} = [0, 0; 1, 0];
    F_grad{2} = [0, 0; 0, 0];

    Psi_grad = cell(2,1); 
    Psi_grad{1} = [0;0];
    Psi_grad{2} = [0;0];
    
    Gamma_grad = cell(2,1);
    Gamma_grad{1} = [0;0];
    Gamma_grad{2} = [0;0];
    
    H_grad = cell(2,1);
    H_grad{1} = [0,0];
    H_grad{2} = [0,0];
    
    Q_grad = cell(2,1);
    Q_grad{1} = 0;
    Q_grad{2} = 1;
        
    R_grad = cell(2,1);
    R_grad{1} = 0;
    R_grad{2} = 0;
    
    x0_grad = cell(2,1);
    x0_grad{1} = [0;0];
    x0_grad{2} = [0;0];
    
    P0_grad = cell(2,1);    
    P0_grad{1} = [0, 0; 0, 0];
    P0_grad{2} = [0, 0; 0, 0];
    
end